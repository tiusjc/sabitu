#
# TABLE STRUCTURE FOR: ppgmc
#

DROP TABLE IF EXISTS ppgmc;

CREATE TABLE `ppgmc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `candidato_id` int(11) NOT NULL,
  `processo_seletivo_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: ppgmc_linhas
#

DROP TABLE IF EXISTS ppgmc_linhas;

CREATE TABLE `ppgmc_linhas` (
  `ppgmc_id` int(11) NOT NULL,
  `linhadepesquisa_id` int(11) NOT NULL,
  PRIMARY KEY (`ppgmc_id`,`linhadepesquisa_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: campos_ppgmc
#

DROP TABLE IF EXISTS campos_ppgmc;

CREATE TABLE `campos_ppgmc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `processo_seletivo_id` int(11) NOT NULL,
  `field` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `label` varchar(200) NOT NULL,
  `rules` varchar(200) NOT NULL,
  `grid` set('S','N') NOT NULL DEFAULT 'N',
  `add_edit` set('S','N') NOT NULL DEFAULT 'N',
  `upload` set('S','N') NOT NULL DEFAULT 'N',
  `ordem` int(2) NOT NULL,
  PRIMARY KEY (`id`,`processo_seletivo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

